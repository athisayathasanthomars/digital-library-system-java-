/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package digital_library;

import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 *
 * @author thoma
 */
public class book_Update extends HttpServlet {
    public Connection Connection;    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        //work on dopost method
        response.setContentType("text/html");
        PrintWriter out=response.getWriter();
        
        String bid=request.getParameter("bookid");
        String bname=request.getParameter("bookname");
        String author=request.getParameter("bookauthor");
        String publisher=request.getParameter("publisher");
        String dateofpublish=request.getParameter("publishdate");
        String category=request.getParameter("category"); 
        try{
          Class.forName("com.mysql.jdbc.Driver");
          Connection con= DriverManager.getConnection("jdbc:mysql://localhost:3306/digital_library", "root", "");
          PreparedStatement stm;
          stm=con.prepareStatement("update book set bookname=?,bookauthor=?,bookpublisher=?,publishdate=?,category=? where bookid=?");
          stm.setString(1,bname);
          stm.setString(2,author);
          stm.setString(3,publisher);
          stm.setString(4,dateofpublish);
          stm.setString(5,category);
          stm.setString(6,bid);
          stm.executeUpdate();
          response.sendRedirect("home.jsp");                   
          con.close();
        }catch(Exception e){
          System.out.println(e.getMessage()); 
        }
    }
}
