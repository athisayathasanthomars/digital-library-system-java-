/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package digital_library;

import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 *
 * @author thoma
 */
public class member_Login extends HttpServlet {
    public Connection Connection;    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        //work on dopost method
        response.setContentType("text/html");
        PrintWriter out=response.getWriter();
        
        String memberid=request.getParameter("memberid");
        String password=request.getParameter("pwd");
        try{
          Class.forName("com.mysql.jdbc.Driver");
          Connection con= DriverManager.getConnection("jdbc:mysql://localhost:3306/digital_library", "root", "");
          Statement stm=con.createStatement();
          ResultSet rs=stm.executeQuery("select * from member_login where memberid='"+memberid+"' and memberpassword='"+password+"'");
          if(rs.next()){
              response.sendRedirect("search.jsp");
          }
          else{
              out.println("Wrong login.Try again..");
          }
          con.close();
        }catch(Exception e){
          System.out.println(e.getMessage()); 
        }        
    }
}
