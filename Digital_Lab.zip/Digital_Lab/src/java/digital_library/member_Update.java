/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package digital_library;

import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.sql.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 *
 * @author thoma
 */
public class member_Update extends HttpServlet {
    public Connection Connection;    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        //work on dopost method
        response.setContentType("text/html");
        PrintWriter out=response.getWriter();
        
        String mid=request.getParameter("memberid");
        String mname=request.getParameter("membername");
        String maddress=request.getParameter("address");
        String memail=request.getParameter("email");
        String mnic=request.getParameter("nic");
        String mphonenumber=request.getParameter("phonenumber");
        try{
          Class.forName("com.mysql.jdbc.Driver");
          Connection con= DriverManager.getConnection("jdbc:mysql://localhost:3306/digital_library", "root", "");
          PreparedStatement stm;
          stm=con.prepareStatement("update member set membername=?,memberaddress=?,email=?,nic=?,phonenumber=? where memberid=?");
          stm.setString(1,mname);
          stm.setString(2,maddress);
          stm.setString(3,memail);
          stm.setString(4,mnic);
          stm.setString(5,mphonenumber);
          stm.setString(6,mid);
          stm.executeUpdate();
          response.sendRedirect("home.jsp");                   
          con.close();
        }catch(Exception e){
          System.out.println(e.getMessage()); 
        }
    }
}
