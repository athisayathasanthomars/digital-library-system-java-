/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package digital_library;

import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;


public class member_Register extends HttpServlet {
    public Connection Connection;
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out=response.getWriter();
        
        String mid=request.getParameter("memberid");
        String mname=request.getParameter("membername");
        String maddress=request.getParameter("address");
        String memail=request.getParameter("email");
        String mnic=request.getParameter("nic");
        String mphonenumber=request.getParameter("phonenumber");  
        try{
          Class.forName("com.mysql.jdbc.Driver");
          Connection con= DriverManager.getConnection("jdbc:mysql://localhost:3306/digital_library", "root", "");
          Statement stm=con.createStatement();
          String insert="INSERT INTO member(memberid,membername,memberaddress,email,nic,phonenumber) VALUES('"+mid+"','"+mname+"','"+maddress+"','"+memail+"','"+mnic+"','"+mphonenumber+"')";
          stm.executeUpdate(insert);
          response.sendRedirect("home.jsp");
                    
          con.close();
        }catch(Exception e){
          System.out.println(e.getMessage()); 
        }
    }
}
